[![Packaging arbitrage](https://github.com/JonathanNdambaPro/arbitrage_lol/actions/workflows/main.yml/badge.svg)](https://github.com/JonathanNdambaPro/arbitrage_lol/actions/workflows/main.yml)
# Vanilla Arbitrage
For now this librarie is vanilla 
